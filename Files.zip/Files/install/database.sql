-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2019 at 10:39 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cc_dogehunter`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `wallet` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uqid` int(11) DEFAULT NULL,
  `status` int(2) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(11) NOT NULL,
  `gateway_id` int(11) NOT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wallet` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trx` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `title`, `details`, `created_at`, `updated_at`) VALUES
(1, 'Affiliate orem 1ipsum dolor', 'Lorem 1ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat', '2018-09-13 08:21:33', '2018-10-03 07:56:53'),
(4, 'Sun Agat  nisi ut aliquip ex ea commodo consequat', 'Lorem 2ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat', '2018-09-13 08:23:00', '2018-10-03 07:56:50'),
(5, 'Terms and Condition', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat', '2018-09-13 08:26:46', '2018-09-13 08:26:46');

-- --------------------------------------------------------

--
-- Table structure for table `gateways`
--

CREATE TABLE `gateways` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wallet` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `val1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `val2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gateways`
--

INSERT INTO `gateways` (`id`, `name`, `minimum`, `wallet`, `val1`, `val2`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Deposit', '50', NULL, 'c9ba2e9f2fad31d84a7f955fc8d75bdb7cf7bb6e42f67f0e6c30f5f8f3bd5854', '0D8BC2C46c6a38Ba1d1790ad73426e8f5644861af1ba4F7E27930933EadED070', 1, '2018-09-12 18:00:00', '2019-01-21 21:57:40'),
(2, 'Withdraw', '10', 'A6cpoaL8XZzE312DvGzfE2mDwSo5MYzhpc', '187a-b2fd-7ed5-gerger', '43424234', 1, '2018-09-12 18:00:00', '2019-01-23 06:06:15');

-- --------------------------------------------------------

--
-- Table structure for table `generals`
--

CREATE TABLE `generals` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Website Title',
  `subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Website Sub-Title',
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ddd',
  `color_two` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cur` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `cursym` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '$',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info@email.com',
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decimal` int(11) NOT NULL DEFAULT '2',
  `daily` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `dhs_price` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `free_dhs` int(11) NOT NULL DEFAULT '0',
  `how_icon_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_icon_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_icon_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_icon_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_text_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_text_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_text_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_text_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about_text` longtext COLLATE utf8mb4_unicode_ci,
  `about_video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_text` mediumtext COLLATE utf8mb4_unicode_ci,
  `count_icon_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_icon_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_icon_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_icon_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_title_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_title_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_title_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_title_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_number_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_number_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_number_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_number_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `generals`
--

INSERT INTO `generals` (`id`, `title`, `subtitle`, `color`, `color_two`, `cur`, `cursym`, `email`, `address`, `phone`, `decimal`, `daily`, `dhs_price`, `free_dhs`, `how_icon_1`, `how_icon_2`, `how_icon_3`, `how_icon_4`, `how_text_1`, `how_text_2`, `how_text_3`, `how_text_4`, `about_text`, `about_video`, `footer_text`, `count_icon_1`, `count_icon_2`, `count_icon_3`, `count_icon_4`, `count_title_1`, `count_title_2`, `count_title_3`, `count_title_4`, `count_number_1`, `count_number_2`, `count_number_3`, `count_number_4`, `created_at`, `updated_at`) VALUES
(1, 'DogeHunter', 'DogeCoin Mining Platform', '16a085', '2980b9', 'DOGE', 'DOGE', 'do-not-reply@thesoftking.com', 'Company Location, Country', '+880 123 456 7890', 8, '0.2', '1', 5, 'user', 'th', 'cog', 'bars', 'Phurchase Cloud  Base GHS', 'Phurchase Cloud  Base GHS', 'Phurchase Cloud  Base GHS', 'Phurchase Cloud  Base GHS', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 14px;\"=\"\"><font size=\"5\" face=\"impact\">There are many variations of passages of Lorem Ipsum available</font></p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 14px;\"=\"\">&nbsp;but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p><div><br></div>', 'https://www.youtube.com/watch?v=yHz4LSZTfE0', 'The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.', 'heart', 'user', 'user', 'user', 'fdsfsd', 'fsdfd', 'fdsfds', 'fdsfdf', '5445', '543435', '53454', '5435345', '2018-09-12 01:22:32', '2019-04-01 02:15:35');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_09_12_065430_create_generals_table', 2),
(4, '2018_09_12_090008_create_accounts_table', 3),
(5, '2018_09_13_112719_create_gateways_table', 4),
(6, '2018_09_13_122126_create_deposits_table', 5),
(7, '2018_09_13_134827_create_faqs_table', 6),
(8, '2018_09_15_061632_create_tracks_table', 7),
(9, '2018_09_15_111708_create_withdraws_table', 8),
(10, '2018_09_15_145332_create_riches_table', 9),
(11, '2018_10_06_111923_create_testimonials_table', 10),
(12, '2018_10_09_124655_create_services_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `icon`, `title`, `detail`, `created_at`, `updated_at`) VALUES
(2, 'user', 'Service Title 2', 'Bangladesh. By this software you can manage your sales, expenses, refund, client and vendor ledger, passport management and many more. It has everything to operate back office of a travel agency.', '2018-11-07 03:24:35', '2018-11-07 03:26:20'),
(3, 'th', 'Service Title', 'Description: Bangladesh. By this software you can manage your sales, expenses, refund, client and vendor ledger, passport management and many more. It has everything to operate back office of a travel agency.', '2018-11-07 03:24:45', '2018-11-07 03:25:07'),
(4, 'bars', 'Service Title 3', 'Description: Bangladesh. By this software you can manage your sales, expenses, refund, client and vendor ledger, passport management and many more. It has everything to operate back office of a travel agency.', '2018-11-07 04:06:02', '2018-11-07 04:06:02');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `company`, `comment`, `created_at`, `updated_at`) VALUES
(2, 'Pranto Roy', 'The Software', 'Bangladesh. By this software you can manage your sales, expenses, refund, client and vendor ledger, passport management and many more. It has everything to operate back office of a travel agency.', '2018-11-07 03:28:35', '2018-11-07 03:29:51'),
(3, 'Production', 'The standard', 'Bangladesh. By this software you can manage your sales, expenses, refund, client and vendor ledger, passport management and many more. It has everything to operate back office of a travel agency.', '2018-11-07 03:30:11', '2018-11-07 03:30:11'),
(4, 'Pranto Roy', 'Bangla Company Update', 'Bangladesh. By this software you can manage your sales, expenses, refund, client and vendor ledger, passport management and many more. It has everything to operate back office of a travel agency.', '2018-11-07 03:30:20', '2018-11-07 03:30:20');

-- --------------------------------------------------------

--
-- Table structure for table `tracks`
--

CREATE TABLE `tracks` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(11) NOT NULL,
  `speed` int(11) NOT NULL DEFAULT '0',
  `balance` double(15,8) NOT NULL DEFAULT '0.00000000',
  `withdraw` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Mr. Admin', 'admin', 'admine@email.com', '$2y$10$w/KEDQREBWVxf21zMmMPQ.CqKhfZGd1ynuG2sYD1Qy9FBJKLA1HD6', 'pn0J89mfEZMApSPYreSuELlSDr2CZyijqUV5miTyByAqMo8MDpOOYoF0O0w1', '2018-09-12 00:38:24', '2018-09-15 08:27:45');

-- --------------------------------------------------------

--
-- Table structure for table `withdraws`
--

CREATE TABLE `withdraws` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(11) NOT NULL,
  `gateway_id` int(11) NOT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trx` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gateways`
--
ALTER TABLE `gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generals`
--
ALTER TABLE `generals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tracks`
--
ALTER TABLE `tracks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `withdraws`
--
ALTER TABLE `withdraws`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `gateways`
--
ALTER TABLE `gateways`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `generals`
--
ALTER TABLE `generals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tracks`
--
ALTER TABLE `tracks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `withdraws`
--
ALTER TABLE `withdraws`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
