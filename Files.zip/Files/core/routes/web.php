<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



//Balance
Route::get('/get-balance', 'AccountController@getBalance')->name('getBalance');
Route::get('/cron-balance', 'AccountController@updateBalance')->name('updateBalance');



//IPN
Route::post('/ipncoinpaydoge', 'PaymentController@ipnCoinPayDoge')->name('ipn.coinPay.doge');
//IPN



Route::get('/', 'VisitorController@welcome')->name('welcome');
Route::view('/contact', 'contact')->name('contact');
Route::post('/contact-message', 'VisitorController@contactMessage')->name('contact-message');

//Admin Routes
Route::get('/admin', 'Auth\LoginController@showLoginForm')->name('login');
Route::get('/login', 'Auth\LoginController@showLoginForm')->name('login');
Route::post('/login', 'Auth\LoginController@login');
Route::post('/logout', 'Auth\LoginController@logout')->name('logout');


//Account Routes
Route::post('/check', 'AccountController@checkAccount')->name('account.check');
Route::post('/exit', 'AccountController@exit')->name('account.exit');

Route::prefix('account')->group(function() {
    Route::get('/', 'AccountController@dashboard');
    Route::get('/dashboard', 'AccountController@dashboard')->name('account.dashboard');
    Route::get('/deposit', 'AccountController@deposit')->name('account.deposit');
    Route::get('/withdraw', 'AccountController@withdraw')->name('account.withdraw');

    //Deposit
    Route::post('/deposit-wallet', 'PaymentController@depositWallet')->name('account.deposit-wallet');
    Route::post('/withdraw-post', 'PaymentController@withdrawPost')->name('account.withdraw-post');
});



Route::group(['middleware' => ['auth']], function() {
Route::prefix('admin')->group(function() {

    Route::get('/dashboard', 'AdminController@index')->name('admin.dashboard');

    Route::get('/howitswork', 'AdminController@howitsIndex')->name('howits.index');
    Route::get('/about-us', 'AdminController@aboutuIndex')->name('about-u.index');
    Route::get('/counter', 'AdminController@counterIndex')->name('counter.index');

    //General Settings
    Route::get('/general', 'AdminController@general')->name('admin.general');
    Route::get('/general', 'AdminController@general')->name('admin.general');
    Route::post('/general-update', 'AdminController@generalUpdate')->name('admin.gnlupdate');

    Route::get('/deposits', 'AdminController@deposits')->name('admin.deposits');
    Route::get('/withdraws', 'AdminController@withdraws')->name('admin.withdraws');

    Route::get('/profile', 'AdminController@profile')->name('admin.profile');
    Route::post('/profile-update', 'AdminController@profileUpdate')->name('admin.proupdate');

    Route::get('/accounts', 'AdminController@accounts')->name('admin.accounts');
    Route::get('/single/{account}', 'AdminController@accountSingle')->name('admin.single');

    //Logo-Icon
    Route::get('/logo-icon', 'AdminController@logoIcon')->name('admin.logo');
    Route::post('/logo-update', 'AdminController@logoUpdate')->name('admin.logoupdate');

    //Payment Gateway
    Route::get('/gateway', 'AdminController@gateway')->name('admin.gateway');
    Route::put('/gateway-update/{gateway}', 'AdminController@gatewayUpdate')->name('admin.gateup');

    //FAQ
    Route::get('/faq-section', 'AdminController@faqSection')->name('admin.faq');
    Route::post('/faq-store', 'AdminController@faqStore')->name('admin.faq-store');
    Route::put('/faq-update/{faq}', 'AdminController@faqUpdate')->name('admin.faq-update');
    Route::put('/faq-delete/{faq}', 'AdminController@faqDestroy')->name('admin.faq-delete');



    Route::resources([
        //team
        'testimonial' => 'TestimonialController',

        //service
        'service' => 'ServiceController',

    ]);
        
});
});
