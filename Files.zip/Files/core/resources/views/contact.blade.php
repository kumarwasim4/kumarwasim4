@extends('layouts.user')

@section('content')

    
      <!-- Feature Area Start -->
    <section id="feature">
        <div class="container">
            <br>
            <br>
            <br>
    <div class="row">
            
                <div class="col-lg-4">
                    <div class="box d-flex">
                        <div class="left d-flex">
                            <p class="d-flex align-self-center">
                               <i class="fas fa-map-marker-alt"></i>
                            </p>
                        </div>
                        <div class="right">
                            <h4>
                               Address
                            </h4>
                            <p>
                              {{ $gnl->address }}
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="box d-flex">
                        <div class="left d-flex">
                            <p class="d-flex align-self-center">
                               <i class="far fa-envelope"></i>
                            </p>
                        </div>
                        <div class="right">
                            <h4>
                               Email
                            </h4>
                            <p>
                               {{ $gnl->email }}
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="box d-flex">
                        <div class="left d-flex">
                            <p class="d-flex align-self-center">
                               <i class="fas fa-phone-square"></i>
                            </p>
                        </div>
                        <div class="right">
                            <h4>
                               Phone
                            </h4>
                            <p>
                              {{ $gnl->phone }}
                            </p>
                        </div>
                    </div>
                </div>
                </div>
               
            </div>
        </div>
    </section>
    <!-- Feature Area End -->

    <footer id="footer">
        <div class="container">
            <div class="row">
                  <div class="col-md-12">
                <h2 style="text-align:center; color:white ">Contact Us</h2>
                </div>

                <div class="col-md-12">
                    <div class="title">

                        <form id="contactForm" >
                            @csrf
                            <div class="form-row">
                                <div class="col-md-6">
                                     <input type="text" name="name" placeholder="Your name here*" required>
                            <input type="email" name="email" placeholder="Your email here*" required>
                            <input type="text" name="subject" placeholder="Your email here*" required>
                                </div>
                                
                                <div class="col-md-6">
                                     <textarea name="message" id="message" style="height: 165px;" placeholder="Massege*"></textarea>
                                </div>
                            </div>
                           
                    
                            <button type="submit" class="offset-md-5">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- Feature Area End -->
@endsection   
@section('scripts')
<script>
  $(document).ready(function(){  
    $(document).on('submit','#contactForm',function(event)
    {
      event.preventDefault();
      $.ajax({
        type:"POST",
        url:"{{route('contact-message')}}",       
        data: new FormData(document.getElementById('contactForm')),
        contentType: false,
        processData: false,
        success:function(data)
        {
            if(data==200)
          {
            $.notify({ allow_dismiss: true,title: "Success!",message: "Message Sent Successfully" }, { type: 'success' });
          }
          else if(data==11)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Email Field is Required" }, { type: 'danger' });
          }
          else if(data==22)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Name Field is Required" }, { type: 'danger' });
          }
          else if(data==33)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Subject Field is Required" }, { type: 'danger' });
          }
          else if(data==44)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Message Field is Required" }, { type: 'danger' });
          }
          else
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "An Error Occured" }, { type: 'danger' });
          }
        }
      });
    });
  });
</script>     
  
  @endsection
