@extends('layouts.user')

@section('content')
    <section id="transaction">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading-title2">
                        <p>
                            {{$gnl->title}}
                        </p>
                        <h2>
                            WITHDRAW
                        </h2>
                    </div>
                </div>
                <div class="col-12 text-center">

                    <div class="card rich" style=" background-color: transparent; color:white; border:1px solid #dee2e6" id="depositCard" style="display:none;">

                        <div class="card-body">
                         {{--<form id="withdrawForm22" action='{{route('account.withdraw-post')}}' method='post'>--}}
                            <form id="withdrawForm">
                                @csrf
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group" >
                                            <select name="track" id="trackId" style=" background-color: transparent; color:white; border:1px solid #dee2e6" id="depositCard" style="display:none;" class="form-control wallet-input">
                                                <option>Select A MINER</option>
                                                @foreach ($tracks as $item)
                                                    <option style="background: black;" value="{{$item->id}}">{{round($item->balance,8)}} {{$gnl->cur}} | {{$item->speed}} DH/S</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <div class="input-group-append">
                                                <input type="number" style=" background-color: transparent; color:white; border:1px solid #dee2e6; " id="depositCard"  class="form-control input-lg wallet-input" name="amount" placeholder="Withdraw Amount">
                                                <span class="input-group-text wallet-input">{{$gnl->cur}}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary btn-block btn-submit">Enter</button>
                                    </div>
                                </div>
                            </form>

                            <hr>
                            <ul class="list-inline">
                                <li class="list-inline-item">Minimum Withdraw: <strong>{{$gateway->minimum}}</strong> {{$gnl->cur}} |</li>
                                <li class="list-inline-item">Your Balance <strong>{{isset($balance) ? round($balance, $gnl->decimal) : 0}}</strong> {{$gnl->cur}}</li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <br>
            <hr>
            <div class="row justify-content-center">
                <h3 style="color: white"> YOUR PAYOUTS</h3>
                <div class="col-md-12">
                    <br>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>AMOUNT</th>
                                <th>TRX ID</th>
                                <th>TRX TIME</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if(count($withdraw)==0)
                                <tr>
                                    <td class="text-center" colspan="3">NO DATA AVAILABLE</td>
                                </tr>
                            @endif
                            @foreach ($withdraw as $item)
                                <tr>
                                    <td>{{$item->amount}} {{$gnl->cur}}</td>
                                    <td>{{$item->trx}}</td>
                                    <td>{{$item->created_at}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {{$withdraw->links()}}
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@section('scripts')
<script>
  $(document).ready(function(){  
    $(document).on('submit','#withdrawForm',function(event)
    {
      event.preventDefault();
      $.ajax({
        type:"POST",
        url:"{{route('account.withdraw-post')}}",       
        data: new FormData(document.getElementById('withdrawForm')),
        contentType: false,
        processData: false,
        success:function(data)
        {
          console.log(data)
          if(data==99)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Invalid Amount" }, { type: 'danger' });
          }
          if(data==33)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Select A Track" }, { type: 'danger' });
          }
          else if(data == 11)
          {
            $.notify({ allow_dismiss: true,title: "Success!",message: "Withdraw Complete" }, { type: 'success' });
          }
          else
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Error Occured" }, { type: 'danger' });
          }
        }
      });
    });
  });
</script>     

@endsection
