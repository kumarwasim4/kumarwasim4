@extends('layouts.user')

@section('content')
    <!-- Transaction Area Start -->
    <section id="transaction">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading-title2">
                    
                        <h2>
                           {{$gnl->title}}
                        </h2>
                    </div>
                </div>
                <div class="col-12 text-center">

                    <div class="card rich" style=" background-color: transparent; color:white; border:1px solid #dee2e6">
                        <div class="card-body">
                            <h2>{{$account->wallet}}</h2>
                        </div>
                    </div>
                    <hr>
                    <div class="card rich" style=" background-color: transparent;color:white; border:1px solid #dee2e6">
                        <div class="card-body">
                            <h1> <strong id="minedAmount">0</strong> {{$gnl->cur}}</h1>
                            <hr>
                            <ul class="list-inline">
                                <li class="list-inline-item">Miner Speed: <strong>{{isset($speed) ? $speed : 0}}</strong> DH/S |</li>
                                <li class="list-inline-item">Daily Profit <strong id="dailyAmount">{{isset($speed) ? $speed*$gnl->daily : 0}}</strong> {{$gnl->cur}}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <hr>
            <div class="row justify-content-center">
                <h3 style="color: white">  Active {{$gnl->cur}} MINERS</h3>
                <div class="col-md-12">
                    <br>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>SPEED</th>
                                <th>WITHDRAW</th>
                                <th>START AT</th>
                                <th>STATUS</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach ($tracks as $item)
                                <tr>
                                    <td>{{$item->speed}} DH/S</td>
                                    <td>{{round($item->withdraw,8)}} {{$gnl->cur}}</td>
                                    <td>{{$item->created_at}}</td>
                                    <td>{{$item->status==1?'Active':'Expired'}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {{$tracks->links()}}
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Transaction Area End -->



@endsection

@section('scripts')
<script>
    $(document).ready(function(){  
        let daily = $('#dailyAmount').text();
        let inMili = daily/864000;
        let incVal = {{isset($balance) ? $balance : 0}};
        setInterval(function(){ 
            incVal = incVal+inMili;
            $('#minedAmount').text(incVal.toFixed(8)); 
        }, 100);
    });
</script>     
@endsection
