@extends('layouts.admin')
@section('content')
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('admin.dashboard')}}">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">FREQUENTLY ASKED QUESTION</li>
</ol>
<div class="card">
    <div class="card-body">
        <div class="card-header">
                <button class="btn btn-md btn-primary mr-auto" data-toggle="modal" data-target="#newfaq">
                        <i class="fa fa-plus"></i> New Faq
                    </button>
        </div>
        
        <div class="row">
            @php $n = 1; @endphp
            @foreach($faqs as $faq)
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center">
                        Faq No: <strong>{{$n}}</strong>
                        <button class="float-right btn btn-sm btn-danger"  data-toggle="modal" data-target="#delModal{{$faq->id}}"><i class="fa fa-trash"></i></button>
                    </div>
                    <div class="card-body">
                        <form role="form" method="POST" action="{{route('admin.faq-update',$faq->id)}}">
                            @csrf
                            @method('put')
                            <div class="form-group">
                                <h4>Faq Title</h4>
                                <input type="text" value="{{$faq->title}}" class="form-control"  name="title" >
                            </div>
                            <div class="form-group">
                                <h4>Faq Details</h4>
                                <textarea name="details" rows="10" class="form-control">{{$faq->details}}</textarea>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-success btn-block">Update</button>
                            </div>
                            
                        </form>
                    </div>
                </div>				
            </div>
            <div id="delModal{{$faq->id}}" class="modal fade" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Delete Faq {{$n}}</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <form role="form" method="POST" action="{{route('admin.faq-delete',$faq)}}" >
                                @csrf
                                @method('put')
                                <button type="submit" class="btn btn-danger btn-block">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            @php $n = $n+1; @endphp
            @endforeach
        </div>
    </div>
</div>
<div id="newfaq" class="modal fade" role="dialog">
    <div class="modal-dialog">
        
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">New Faq </h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="{{route('admin.faq-store')}}">
                    @csrf
                    
                    <div class="form-group">
                        <h4>Faq Title</h4>
                        <input type="text"  class="form-control"  name="title" >
                    </div>
                    <div class="form-group">
                        <h4>Faq Details</h4>
                        <textarea name="details" rows="10" class="form-control"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-success btn-block">Create</button>
                    </div>
                    
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
            </div>
        </div>
        
    </div>
</div>
@endsection
