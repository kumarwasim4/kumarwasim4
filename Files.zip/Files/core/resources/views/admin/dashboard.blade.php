@extends('layouts.admin')

@section('content')
<!-- Breadcrumbs-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="{{route('admin.dashboard')}}">Dashboard</a>
  </li>
  <li class="breadcrumb-item active">Statistics</li>
</ol>

<!-- Page Content -->
<div class="card">
    <div class="card-header">MINING TRACKS
    </div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>ACCOUNT</th>
                    <th>SPEED</th>
                    <th>BALANCE</th>
                    <th>WITHDRAW</th>
                    <th>START AT</th>
                    <th>STATUS</th>
                </tr>
            </thead>
            <tbody>
                    @if(count($tracks)==0)
                    <tr>
                        <td class="text-center" colspan="6">NO DATA AVAILABLE</td>
                    </tr>
                    @endif
                @foreach ($tracks as $item)
                @php
                 $diff = ($now->diffInSeconds($item->created_at));
                 $daily = $item->speed*$gnl->daily;
                 $perSec = $daily/86400;
                 $total = $diff*$perSec;
                 $balance = $total - $item->withdraw;    
                @endphp
                <tr>
                    <td><a href="{{route('admin.single', $item->account_id)}}">{{$item->account->wallet}}</a></td>
                    <td>{{$item->speed}} DH/S</td>
                    <td>{{round($balance,8)}} {{$gnl->cur}}</td>
                    <td>{{round($item->withdraw,8)}} {{$gnl->cur}}</td>
                    <td>{{$item->created_at}}</td>
                    <td>{{$item->status==1?'Active':'Expired'}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {{$tracks->links()}}
    </div>
</div>
@endsection
