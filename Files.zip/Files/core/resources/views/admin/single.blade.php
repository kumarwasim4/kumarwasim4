@extends('layouts.admin')

@section('content')
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('admin.dashboard')}}">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">ACCOUNT of <strong>{{$account->uqid}}</strong></li>
</ol>


<div class="card">
    <div class="card-header">
        TRACKS of <strong>{{$account->uqid}}</strong>
    </div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>SPEED</th>
                    <th>BALANCE</th>
                    <th>WITHDRAW</th>
                    <th>START AT</th>
                    <th>STATUS</th>
                </tr>
            </thead>
            <tbody>
                @if(count($track)==0)
                <tr>
                    <td class="text-center" colspan="5">NO DATA AVAILABLE</td>
                </tr>
                @endif
                @foreach ($track as $item)
                @php
                $diff = ($now->diffInSeconds($item->created_at));
                $daily = $item->speed*$gnl->daily;
                $perSec = $daily/86400;
                $total = $diff*$perSec;
                $balance = $total - $item->withdraw;    
                @endphp
                <tr>
                    <td>{{$item->speed}} DH/S</td>
                    <td>{{round($balance,8)}} {{$gnl->cur}}</td>
                    <td>{{round($item->withdraw,8)}} {{$gnl->cur}}</td>
                    <td>{{$item->created_at}}</td>
                    <td>{{$item->status==1?'Active':'Expired'}}</td>
                </tr>
                @endforeach
            </tbody>
            
        </table>
    </div>
</div>
<hr>
<div class="card">
    <div class="card-header">
        DEPOSIT of <strong>{{$account->uqid}}</strong>
    </div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>AMOUNT</th>
                    <th>WALLET</th>
                    <th>TRX ID</th>
                    <th>TRX TIME</th>
                </tr>
            </thead>
            <tbody>
                @if(count($deposit)==0)
                <tr>
                    <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                </tr>
                @endif
                @foreach ($deposit as $item)
                <tr>
                    <td>{{$item->amount}} {{$gnl->cur}}</td>
                    <td>{{$item->wallet}}</td>
                    <td>{{$item->trx}}</td>
                    <td>{{$item->updated_at}}</td>
                </tr>
                @endforeach
            </tbody>
            
        </table>
    </div>
</div>
<hr>
<div class="card">
    <div class="card-header">
        PAYOUTS of <strong>{{$account->uqid}}</strong>
    </div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>AMOUNT</th>
                    <th>WALLET</th>
                    <th>TRX ID</th>
                    <th>TRX TIME</th>
                </tr>
            </thead>
            <tbody>
                @if(count($withdraw)==0)
                <tr>
                    <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                </tr>
                @endif
                @foreach ($withdraw as $item)
                <tr>
                    <td>{{$item->amount}} {{$gnl->cur}}</td>
                    <td>{{$item->account->wallet}}</td>
                    <td>{{$item->trx}}</td>
                    <td>{{$item->created_at}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
