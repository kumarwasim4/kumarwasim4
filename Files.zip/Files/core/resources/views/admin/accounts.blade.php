@extends('layouts.admin')

@section('content')
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('admin.dashboard')}}">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">ACCOUNTS</li>
</ol>

<!-- Page Content -->
<div class="card">
    <div class="card-header">USER ACCOUNTS</div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <td>Wallet</td>
                    <td>Unique ID</td>
                    <td>View</td>
                </tr>
            </thead>
            <tbody>
                    @if(count($accounts)==0)
                    <tr>
                        <td class="text-center" colspan="3">NO DATA AVAILABLE</td>
                    </tr>
                    @endif
                @foreach ($accounts as $item)
                <tr>
                    <td>{{$item->wallet}}</td>
                    <td>{{$item->uqid}}</td>
                    <td><a href="{{route('admin.single', $item->id)}}" class="btn btn-info">Details</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {{$accounts->links()}}
    </div>
</div>
@endsection
