@extends('layouts.admin')

@section('content')
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('admin.dashboard')}}">Dashboard</a>
    </li>

    <li class="breadcrumb-item active">
        <a href="https://fontawesome.com/v4.7.0/icons/" target="_blank" class="btn btn-primary">Font Awesome Icons</a>
    </li>
</ol>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                @include('layouts.error')
                <form role="form" method="POST" action="{{route('admin.gnlupdate')}}">
                    @csrf
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Statistic Counter 1</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Icon <i class="fa fa-{{$general->count_icon_1}}"></i></label>
                                        <input type="text" class="form-control input-lg" value="{{$general->count_icon_1}}" name="count_icon_1" required>
                                    </div>
                                     <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control input-lg" value="{{$general->count_title_1}}" name="count_title_1" required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Count Number</label>
                                        <input type="number" class="form-control input-lg" value="{{$general->count_number_1}}" name="count_number_1" required>
                                    </div>

                                </div>
                            </div>

                        </div>


                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Statistic Counter 2</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Icon <i class="fa fa-{{$general->count_icon_2}}"></i></label>
                                        <input type="text" class="form-control input-lg" value="{{$general->count_icon_2}}" name="count_icon_2" required>
                                    </div>
                                     <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control input-lg" value="{{$general->count_title_2}}" name="count_title_2" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Count Number</label>
                                        <input type="number" class="form-control input-lg" value="{{$general->count_number_2}}" name="count_number_2" required>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Statistic Counter 3</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Icon <i class="fa fa-{{$general->count_icon_3}}"></i></label>
                                        <input type="text" class="form-control input-lg" value="{{$general->count_icon_3}}" name="count_icon_3" required>
                                    </div>
                                     <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control input-lg" value="{{$general->count_title_3}}" name="count_title_3" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Count Number</label>
                                        <input type="number" class="form-control input-lg" value="{{$general->count_number_3}}" name="count_number_3" required>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Statistic Counter 4</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Icon <i class="fa fa-{{$general->count_icon_4}}"></i></label>
                                        <input type="text" class="form-control input-lg" value="{{$general->count_icon_4}}" name="count_icon_4" required>
                                    </div>
                                     <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control input-lg" value="{{$general->count_title_4}}" name="count_title_4" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Count Number</label>
                                        <input type="number" class="form-control input-lg" value="{{$general->count_number_4}}" name="count_number_4" required>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                  <br>
                    
                    <div class="row">
                        <div class="col-md-6 ml-auto mr-auto">
                            <button class="btn btn-success btn-block btn-lg">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
	
</div>
@endsection
