@extends('layouts.admin')

@section('content')
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('admin.dashboard')}}">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">DEPOSITS</li>
</ol>
<div class="card">
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>ACCOUNT</th>
                    <th>AMOUNT</th>
                    <th>RECEIVER</th>
                    <th>TRX ID</th>
                    <th>TRX TIME</th>
                </tr>
            </thead>
            <tbody>
                    @if(count($deposits)==0)
                    <tr>
                        <td class="text-center" colspan="5">NO DATA AVAILABLE</td>
                    </tr>
                    @endif
                @foreach ($deposits as $item)
                <tr>
                    <td><a href="{{route('admin.single', $item->account_id)}}">{{$item->account->wallet}}</a></td>
                    <td>{{$item->amount}} {{$gnl->cur}}</td>
                    <td>{{$item->wallet}}</td>
                    <td>{{$item->trx}}</td>
                    <td>{{$item->created_at}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {{$deposits->links()}}
    </div>
</div>
@endsection
