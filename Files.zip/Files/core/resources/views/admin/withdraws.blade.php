@extends('layouts.admin')

@section('content')
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('admin.dashboard')}}">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">PAYOUTS</li>
</ol>
<div class="card">
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>ACCOUNT</th>
                    <th>AMOUNT</th>
                    <th>TRX ID</th>
                    <th>TRX TIME</th>
                </tr>
            </thead>
            <tbody>
                    @if(count($withdraws)==0)
                    <tr>
                        <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                    </tr>
                    @endif
                @foreach ($withdraws as $item)
                <tr>
                    <td><a href="{{route('admin.single', $item->account_id)}}">{{$item->account->wallet}}</a></td>
                    <td>{{$item->amount}} {{$gnl->cur}}</td>
                    <td>{{$item->trx}}</td>
                    <td>{{$item->created_at}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {{$withdraws->links()}}
    </div>
</div>
@endsection
