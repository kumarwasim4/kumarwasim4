@extends('layouts.admin')

@section('content')
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('admin.dashboard')}}">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Profile Settings</li>
</ol>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                @include('layouts.error')
                <form  method="POST" action="{{ route('admin.proupdate') }}">
                    @csrf
                    <div class="card">
                        <div class="card-header">Admin Information</div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Name</label>
                                <input class="form-control" type="text" name="name" value="{{$admin->name}}" required>
                            </div>
                            <div class="form-group">
                                <label>User Name</label>
                                <input class="form-control" type="text" name="username" value="{{$admin->username}}" required>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input class="form-control" type="email" name="email" value="{{$admin->email}}" required>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="card">
                        <div class="card-header">Change Password (Optional)</div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" type="password" name="password">
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input class="form-control" type="password" name="conpassword">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <hr>
                        <button type="submit" class="btn btn-success btn-lg btn-block" style="width:100%">
                            Update Profile
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
