<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Deposit extends Model
{
    protected $fillable = array( 'account_id','gateway_id','amount','wallet','trx','status');

    public function account()
    {
        return $this->belongsTo('App\Account');
    }
    public function gateway()
    {
        return $this->belongsTo('App\Gateway');
    }
}
