<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    protected $fillable = ['wallet','uqid'];

   public function deposit()
   {
       return $this->hasMany('App\Deposit','id','account_id');
   }
   public function withdraw()
   {
       return $this->hasMany('App\Withdraw','id','account_id');
   }
   public function track()
   {
       return $this->hasMany('App\Track','id','account_id');
   }
}
