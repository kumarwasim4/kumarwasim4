<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Track extends Model
{
    protected $fillable = array( 'account_id','speed','withdraw','status');

    public function account()
    {
        return $this->belongsTo('App\Account');
    }
}
