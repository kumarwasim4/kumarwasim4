<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Withdraw extends Model
{
    protected $fillable = array( 'account_id','gateway_id','amount','trx');

    public function account()
    {
        return $this->belongsTo('App\Account');
    }
    public function gateway()
    {
        return $this->belongsTo('App\Gateway');
    }
}
