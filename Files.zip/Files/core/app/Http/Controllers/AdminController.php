<?php

namespace App\Http\Controllers;

use App\Faq;
use App\User;
use App\Track;
use App\Account;
use App\Deposit;
use App\Gateway;
use App\General;
use App\Withdraw;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    

    public function index()
    {
        $tracks = Track::orderBy('id','DESC')->paginate(25);
        $now = Carbon::now();
        return view('admin.dashboard',compact('tracks','now'));
    }
    
    public function general()
    {
        $general = General::first();
        if(is_null($general))
        {
            $default = ['title' => 'Website Title'];
            General::create($default);
            $general = General::first();
        }        
        return view('admin.general', compact('general'));
    }


    public function howitsIndex()
    {
        $general = General::first();
        return view('admin.howits', compact('general'));
    }

    public function aboutuIndex()
    {
        $general = General::first();
        return view('admin.about-us', compact('general'));
    }

    public function counterIndex()
    {
        $general = General::first();
        return view('admin.statis', compact('general'));
    }
      
    public function generalUpdate(Request $request)
    {
        $general = General::first();



        $general['title'] = $request->title == '' ? $general->title: $request->title;
        $general['subtitle'] = $request->subtitle == '' ? $general->subtitle: $request->subtitle;
        $general['color'] = $request->color == ''? $general->color :ltrim($request->color,'#');
        $general['color_two'] = $request->color_two == ''? $general->color_two :ltrim($request->color_two,'#');
        $general['cur'] = $request->cur== '' ? $general->cur: $request->cur;
        $general['cursym'] = $request->cursym == '' ? $general->cursym: $request->cursym;
        $general['decimal'] = $request->decimal == '' ? $general->decimal: $request->decimal;
        $general['email'] = $request->email == '' ? $general->email: $request->email;
        $general['daily'] = $request->daily== '' ? $general->daily: $request->daily;
        $general['dhs_price'] = $request->dhs_price== '' ? $general->dhs_price: $request->dhs_price;
        $general['free_dhs'] = $request->free_dhs== '' ? $general->free_dhs: $request->free_dhs;

        $general['how_icon_1'] = $request->how_icon_1== '' ? $general->how_icon_1: $request->how_icon_1;
        $general['how_text_1'] = $request->how_text_1== '' ? $general->how_text_1: $request->how_text_1;

        $general['how_icon_2'] = $request->how_icon_2== '' ? $general->how_icon_2: $request->how_icon_2;
        $general['how_text_2'] = $request->how_text_2== '' ? $general->how_text_2: $request->how_text_2;

        $general['how_icon_3'] = $request->how_icon_3== '' ? $general->how_icon_3: $request->how_icon_3;
        $general['how_text_3'] = $request->how_text_3== '' ? $general->how_text_3: $request->how_text_3;

        $general['how_icon_4'] = $request->how_icon_4== '' ? $general->how_icon_4: $request->how_icon_4;
        $general['how_text_4'] = $request->how_text_4== '' ? $general->how_text_4: $request->how_text_4;

        $general['about_video'] = $request->about_video== '' ? $general->about_video: $request->about_video;
        $general['about_text'] = $request->about_text== '' ? $general->about_text: $request->about_text;

        $general['footer_text'] = $request->footer_text== '' ? $general->footer_text: $request->footer_text;


        $general['count_icon_1'] = $request->count_icon_1== '' ? $general->count_icon_1: $request->count_icon_1;
        $general['count_icon_2'] = $request->count_icon_2== '' ? $general->count_icon_2: $request->count_icon_2;
        $general['count_icon_3'] = $request->count_icon_3== '' ? $general->count_icon_3: $request->count_icon_3;
        $general['count_icon_4'] = $request->count_icon_4== '' ? $general->count_icon_4: $request->count_icon_4;


        $general['count_title_1'] = $request->count_title_1== '' ? $general->count_title_1: $request->count_title_1;
        $general['count_title_2'] = $request->count_title_2== '' ? $general->count_title_2: $request->count_title_2;
        $general['count_title_3'] = $request->count_title_3== '' ? $general->count_title_3: $request->count_title_3;
        $general['count_title_4'] = $request->count_title_4== '' ? $general->count_title_4: $request->count_title_4;

        $general['count_number_1'] = $request->count_number_1== '' ? $general->count_number_1: $request->count_number_1;
        $general['count_number_2'] = $request->count_number_2== '' ? $general->count_number_2: $request->count_number_2;
        $general['count_number_3'] = $request->count_number_3== '' ? $general->count_number_3: $request->count_number_3;
        $general['count_number_4'] = $request->count_number_4== '' ? $general->count_number_4: $request->count_number_4;
        
        $general['address'] = $request->address== '' ? $general->address: $request->address;
        $general['phone'] = $request->phone== '' ? $general->phone: $request->phone;

        $general->update();


        if ($request->hasFile('about_image')) {
            $image = $request->file('about_image');
            $filename = 'about_image.png';
            $location = 'assets/images/' . $filename;
            Image::make($image)->save($location);
        }

        if ($request->hasFile('banner_image')) {
            $image = $request->file('banner_image');
            $filename = 'banner_image.png';
            $location = 'assets/images/' . $filename;
            Image::make($image)->save($location);
        }
        
        return back()->with('success', 'General Settings Updated Successfully');
    }

    public function accounts()
    {
        $accounts = Account::orderBy('id','DESC')->paginate(20);
        return view('admin.accounts', compact('accounts'));
    }

    public function accountSingle($id)
    {
        $account = Account::find($id);
        $withdraw = Withdraw::where('account_id', $account->id)->get();
        $deposit = Deposit::where('id','status')->where('account_id', $account->id)->get();
        $track = Track::where('account_id', $account->id)->get();
        $now = Carbon::now();
        return view('admin.single', compact('account','withdraw','deposit','track','now'));
    }
    
    
    public function withdraws()
    {
        $withdraws = Withdraw::orderBy('id','DESC')->paginate(25);
        return view('admin.withdraws', compact('withdraws'));
    }
    public function deposits()
    {
        $deposits = Deposit::where('status',1)->orderBy('id','DESC')->paginate(25);
        return view('admin.deposits', compact('deposits'));
    }
    public function profile()
    {
        $admin = User::find(Auth::id());
        return view('admin.profile', compact('admin'));
    }
    
    public function profileUpdate(Request $request)
    {
        $this->validate($request, ['name' => 'required','username' => 'required', 'email' => 'required']);
        $admin = User::find(Auth::id());
        $admin['name'] = $request->name;
        $admin['username'] = $request->username;
        $admin['email'] = $request->email;
        if(isset($request->password))
        {
            if($request->password == $request->conpassword)
            {
                $admin['password'] = Hash::make($request->password);
            }
            else
            {
                return back()->with('alert', 'Password NOT MATCHED');
            }

        }
     
        $admin->update();
        
        return back()->with('success','Admin Profile Updated Successfully');
    }
    public function gateway()
    {
        $deposit = Gateway::find(1);
        $withdraw = Gateway::find(2);
        return view('admin.gateway', compact('deposit','withdraw'));
    }
    
    public function gatewayUpdate(Request $request, $id)
    {
        $this->validate($request, ['name' => 'required']);
        $gateway = Gateway::find($id);
        $gateway['name'] = $request->name;
        $gateway['minimum'] = $request->minimum;
        $gateway['wallet'] = $request->wallet;
        $gateway['val1'] = $request->val1;
        $gateway['val2'] = $request->val2;
        $gateway->update();
        
        return back()->with('success','Gateway Information Updated Successfully');
    }
    
    
    public function logoIcon()
    {
        return view('admin.logo');
    }
    
    public function logoUpdate(Request $request)
    {
        $this->validate($request, ['logo' => 'image|mimes:jpeg,png,jpg|max:4048','icon' => 'image|mimes:jpeg,png,jpg|max:4048']);
        
        if($request->hasFile('logo'))
        {
            Image::make($request->logo)->save('assets/images/logo.png');
        }
        if($request->hasFile('icon'))
        {
            Image::make($request->icon)->resize(128, 128)->save('assets/images/icon.png');
        }
        return back()->with('success','Logo and Icon Updated successfully.');
    }
    
    public function faqSection()
    {
        $faqs = Faq::all();
        return view('admin.faq', compact('faqs'));
    }

    public function faqStore(Request $request)
    {
        $this->validate($request, ['title' => 'required','details' => 'required']);
        
        $faq['title'] = $request->title;
        $faq['details'] = $request->details;
        Faq::create($faq);
        
        return back()->with('success', 'New Faq Created Successfully!');
    }
    
    public function faqUpdate(Request $request, $id)
    {
        $faq = Faq::find($id);
        $this->validate($request, ['title' => 'required','details' => 'required']);
        $faq['title'] = $request->title;
        $faq['details'] = $request->details;
        $faq->update();
        
        return back()->with('success', 'Faq Updated Successfully!');
    }
    
    public function faqDestroy($id)
    {
        $faq = Faq::findOrFail($id);
        
        $faq->delete();
        
        return back()->with('success', 'Faq Deleted Successfully!');
    }
    
}
