<?php

namespace App\Http\Controllers;

use App\Track;
use App\Account;
use App\Deposit;
use App\Gateway;
use App\General;
use App\Withdraw;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    public function dashboard()
    {
        $curAc = session('CurrentAccount');
        $account = Account::where('wallet', $curAc)->first();
        if(isset($account))
        {
            $tracks = Track::where('account_id', $account->id)->orderBy('id', 'DESC')->paginate(10);
            $speed = Track::where('account_id', $account->id)->sum('speed');
            $balance = $this->getBalance($account->id);
            return view('account.index',compact('account','tracks','speed','balance'));
        }
        else
        {
            return redirect('/');
        }
    }
    
    public function deposit()
    {
        $curAc = session('CurrentAccount');
        $account = Account::where('wallet', $curAc)->first();
        if(isset($account))
        {
            $deposits = Deposit::where('account_id', $account->id)->where('status',1)->paginate(10);
            $gateway = Gateway::select('minimum')->find(1);
            return view('account.deposit',compact('account','gateway','deposits'));
        }
        else
        {
            return redirect('/');
        }

    }

    public function withdraw()
    {
        $curAc = session('CurrentAccount');
        $account = Account::where('wallet', $curAc)->first();
        if(isset($account))
        {
            $balance = $this->getBalance($account->id);
            $tracks = Track::where('account_id', $account->id)->get();
            $withdraw = Withdraw::where('account_id', $account->id)->paginate(10);
            $gateway = Gateway::select('minimum')->find(2);
            return view('account.withdraw',compact('account','gateway','withdraw','balance','tracks'));
        }
        else
        {
            return redirect('/');
        }

    }
   
    public function checkAccount(Request $request)
    {
        $ch = curl_init('https://dogechain.info/api/v1/address/balance/'.$request->wallet);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($ch);
        curl_close($ch);
        $type = json_decode($data,true);
        if($type['success']==1)
        {
          
            $account = Account::where('wallet', $request->wallet)->first();
            if(isset($account))
            {
                session()->put('CurrentAccount', $request->wallet);
                return 11;
            }
            else
            {
                $acc['wallet'] = $request->wallet;
                $acc['balance'] = 0;
                $acc['uqid'] = rand(10000000,99999999);
                $ck = Account::where('uqid', $acc['uqid'])->first();
                if(isset($ck))
                {
                    $acc['uqid'] = rand(10000000,99999999);
                }
                Account::create($acc);

                $last = Account::where('wallet', $request->wallet)->first();
                $gnl = General::first();
                $track['account_id'] = $last->id; 
                $track['speed'] = $gnl->free_dhs;
                $track['balance'] = 0;
                $track['status'] =1;
                Track::create($track);

                session()->put('CurrentAccount', $request->wallet);
                
                return 12;
            }
        }
        else
        {
            return 99;
        }
        
    }

    public function getBalance($wallet)
    {
        
        $tracks = Track::where('status', 1)->where('account_id', $wallet)->sum('balance');
        return $tracks;
    }







    
    
 public function updateBalance(){
     
     

$gnl = General::first();
$tracks = Track::where('status', 1)->get();
        
foreach($tracks as $tr){
            $now = Carbon::now();
            $diff = ($now->diffInSeconds($tr->updated_at));
            $daily = $tr->speed*$gnl->daily;
            $perSec = $daily/86400;
            $total = round($diff*$perSec, 8);
echo "$total <br>";
            
            $tup = Track::find($tr->id);
            $tup->balance  += $total;
            $tup->update();
}


    }




    
    public function exit()
    {
        session()->forget('CurrentAccount');
        return redirect('/');
    }
}
