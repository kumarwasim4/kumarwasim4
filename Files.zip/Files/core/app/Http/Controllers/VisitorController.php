<?php

namespace App\Http\Controllers;

use App\Faq;
use App\Service;
use App\Testimonial;
use App\Track;
use App\Account;
use App\Deposit;
use App\General;
use App\Withdraw;
use Carbon\Carbon;
use Illuminate\Http\Request;

class VisitorController extends Controller
{
    public function welcome()
    {
        $gnl = General::first();
        $now = Carbon::now();
        $richs = Track::orderBy('speed','DESC')->take(10)->get();
        $faqs = Faq::all();
        $testimonial = Testimonial::all();
        $service = Service::all();
        $curAc = session('CurrentAccount');
        $deposit = Deposit::where('status',1)->orderBy('id','DESC')->take(25)->get();
        $withdraw = Withdraw::orderBy('id','DESC')->take(25)->get();
        if(isset($curAc))
        {
            $account = Account::where('wallet', $curAc)->first();
            if(isset($account))
            {
                return redirect()->route('account.dashboard');
            }
            else
            {
                return view('welcome', compact('earnings','richs','faqs','deposit','withdraw', 'service','testimonial'));
            }
        }
        else
        {
            return view('welcome', compact('earnings','richs','now', 'faqs','deposit','withdraw', 'service','testimonial'));
        }
    }
    
    public function faq()
    {
        $faqs = Faq::all();
        return view('faq',compact('faqs')); 
    }
    
    public function stats()
    {
        $deposit = Deposit::where('status',1)->orderBy('id','DESC')->take(25)->get();
        $withdraw = Withdraw::orderBy('id','DESC')->take(25)->get();
        return view('stats',compact('deposit','withdraw')); 
    }
    
    public function contactMessage(Request $request)
    {
        $gnl = General::first();
        
        $to = $gnl->email;
        $from = $request->email;
        $name =  $request->name;
        $subject =  $request->subject;
        $message = $request->message;
        
        if(is_null($from))
        {
            return 11;
        }
        else if(is_null($name))
        {
            return 22;
        }
        else if(is_null($subject))
        {
            return 33;
        }
        else if(is_null($message))
        {
            return 44;
        }
        else
        {

            $headers = "From: $gnl->title <$from> \r\n";
            $headers .= "Reply-To: $gnl->title <$from> \r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            
            mail($to, $subject, $message, $headers);
            
            return 200;
        }
        
    }
}
