<?php

namespace App\Http\Controllers;

use App\Track;
use App\Account;
use App\Deposit;
use App\Gateway;
use App\General;
use App\Withdraw;
use App\Lib\BlockIo;
use Illuminate\Http\Request;
use App\Lib\CoinPaymentHosted;


class PaymentController extends Controller
{
    public function depositWallet()
    {
        $curAc = session('CurrentAccount');
        $account = Account::where('wallet', $curAc)->first();
        if(isset($account))
        {
            $method = Gateway::find(1);
            
            $cps = new CoinPaymentHosted();
            $cps->Setup($method->val2,$method->val1);
            $callbackUrl = route('ipn.coinPay.doge');
            
            $result = $cps->GetCallbackAddress('DOGE', $callbackUrl);
 
            if($result['error'] == 'ok')
            {
                $wallet = $result['result']['address'];
                
                $dep['account_id'] = $account->id;
                $dep['gateway_id'] = 1;
                $dep['amount'] = 0;
                $dep['wallet'] = $wallet;
                $dep['trx'] = str_random(12);
                $dep['status'] = 0;
                Deposit::create($dep);                
                return $wallet;
            }
            else
            {
                return 99;
            }            
        }
        else
        {
            return redirect('/');
        }
        
    }
    public function withdrawPost(Request $request)
    {
        

$curAc = session('CurrentAccount');
$account = Account::where('wallet', $curAc)->first();
$track = Track::find($request->track);


if($track->account_id == $account->id){
    
                    $method = Gateway::find(2);
  
                
                if($request->amount > $track->balance || $request->amount < 0 || $request->amount == '' || $request->amount < $method->minimum ){
                    return 99;
                }else{
                    $apiKey = $method->val1;
                    $version = 2; 
                    $pin =  $method->val2;
                    $block_io = new BlockIo($apiKey, $pin, $version);
                    
                    $convert = $block_io->withdraw_from_addresses(array('amounts' =>  $request->amount, 'from_addresses' => $method->wallet, 'to_addresses' => $account->wallet));
                    
                    if($convert->status == "success"){
                        $track['balance'] =   $track->balance - $request->amount;
                        $track['withdraw'] =  $track->withdraw + $request->amount;
                        $track['updated_at'] =  $track->updated_at;
                        $track->update();

                        $with['account_id'] = $account->id;
                        $with['gateway_id'] = $method->id;
                        $with['amount'] = $request->amount;
                        $with['trx'] = str_random(12);
                        Withdraw::create($with);
                        return 11;

                    }
                    else
                    {
                        return 22;
                    }
                }
    
    
}else{
     return redirect('/');
}

        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public function ipnCoinPayDoge(Request $request)
    {
        
$m = "";

foreach ($_POST as $key => $value){
$m.= "$".htmlspecialchars($key)." = ".htmlspecialchars($value)."
-
";
}
$m.= "----------------------";

foreach ($_GET as $key => $value){
$m.= "$".htmlspecialchars($key)." = ".htmlspecialchars($value)."
-
";
}

$m.= "

----------------------

";

$file = fopen("75.txt","a");
fwrite($file,"$m - \n");
fclose($file);



$data = Deposit::where('status',0)->where('wallet', $request->address)->orderBy('id', 'DESC')->first();
        if ($request->status>=100 || $request->status==2) 
        {
            $data['amount'] = $request->amount;
            $data['status'] = 1;
            $data->update();
            
            $gnl = General::first();
            $track['account_id'] = $data->account_id; 
            $track['speed'] =  intval($request->amount/$gnl->dhs_price);
            $track['balance'] = 0;
            $track['status'] =1;
            Track::create($track);
        }
    }
}
