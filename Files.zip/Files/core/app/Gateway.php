<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gateway extends Model
{
    protected $fillable = array('name', 'minimum', 'wallet','val1', 'val2', 'status');

   public function deposit()
   {
       return $this->hasMany('App\Deposit','id','gateway_id');
   }
   public function withdraw()
   {
       return $this->hasMany('App\Withdraw','id','gateway_id');
   }
}
