<?php

namespace App\Providers;

use App\General;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        $gnl = General::first();
        if(is_null($gnl))
        {
            $default = ['title' => 'Website'];
            General::create($default);
            $gnl = General::first();
        }
        view()->share('gnl',  $gnl);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
    

}
