<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGeneralsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('generals', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title')->default('Website Title');
            $table->string('subtitle')->default('Website Sub-Title');
            $table->string('color')->default('#ddd');
            $table->string('cur')->default('USD');
            $table->string('cursym')->default('$');
            $table->string('email')->default('info@email.com');
            $table->integer('decimal')->default('2');
            $table->timestamps();
        });
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('generals');
    }
}
