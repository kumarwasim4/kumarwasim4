<?php $__env->startSection('content'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Payment Gateway</li>
</ol>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="card text-white <?php echo e($deposit->status==1?'bg-dark':'bg-secondary'); ?>">
                    <div class="card-header text-center">
                        COINPAYMENT DEPOSIT GATEWAY
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('admin.gateup', $deposit)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group">
                                <label>Name of Gateway</label>
                                <input type="text" value="<?php echo e($deposit->name); ?>" class="form-control" id="name" name="name" >
                            </div>
                            <div class="form-group">
                                <label for="minimum">Minimum Amount</label>
                                <div class="input-group-append">
                                    <input type="text" value="<?php echo e($deposit->minimum); ?>" class="form-control" id="minimum" name="minimum" >
                                    <span class="input-group-text">
                                        <?php echo e($gnl->cur); ?>

                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="val1">Public Key</label>
                                <input type="text" value="<?php echo e($deposit->val1); ?>" class="form-control" id="val1" name="val1" >
                            </div>
                            <div class="form-group">
                                <label for="val2">Private KEY</label>
                                <input type="text" value="<?php echo e($deposit->val2); ?>" class="form-control" id="val2" name="val2" >
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success btn-block">Update</button>
                            </div>
                        </form>
                    </div>
                </div>				
            </div>   
            <div class="col-md-6">
                <div class="card text-white <?php echo e($withdraw->status==1?'bg-dark':'bg-secondary'); ?>">
                    <div class="card-header text-center">
                        BLOCK.IO WITHDRAW GATEWAY
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('admin.gateup', $withdraw)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group">
                                <label>Name of Gateway</label>
                                <input type="text" value="<?php echo e($withdraw->name); ?>" class="form-control" id="name" name="name" >
                            </div>
                            <div class="form-group">
                                <label for="minimum">Minimum Amount</label>
                                <div class="input-group-append">
                                    <input type="text" value="<?php echo e($withdraw->minimum); ?>" class="form-control" id="minimum" name="minimum" >
                                    <span class="input-group-text">
                                        <?php echo e($gnl->cur); ?>

                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="wallet">Wallet</label>
                                <input type="text" value="<?php echo e($withdraw->wallet); ?>" class="form-control" id="wallet" name="wallet" >
                            </div>
                            <div class="form-group">
                                <label for="val1">API KEY</label>
                                <input type="text" value="<?php echo e($withdraw->val1); ?>" class="form-control" id="val1" name="val1" >
                            </div>
                            <div class="form-group">
                                <label for="val2">API PIN</label>
                                <input type="text" value="<?php echo e($withdraw->val2); ?>" class="form-control" id="val2" name="val2" >
                            </div>
                
                            <div class="form-group">
                                <button type="submit" class="btn btn-success btn-block">Update</button>
                            </div>
                        </form>
                    </div>
                </div>				
            </div>   
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>