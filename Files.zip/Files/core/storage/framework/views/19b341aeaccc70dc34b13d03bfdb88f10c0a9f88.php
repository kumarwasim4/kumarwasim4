

<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">ACCOUNT of <strong><?php echo e($account->uqid); ?></strong></li>
</ol>


<div class="card">
    <div class="card-header">
        TRACKS of <strong><?php echo e($account->uqid); ?></strong>
    </div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>SPEED</th>
                    <th>BALANCE</th>
                    <th>WITHDRAW</th>
                    <th>START AT</th>
                    <th>STATUS</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($track)==0): ?>
                <tr>
                    <td class="text-center" colspan="5">NO DATA AVAILABLE</td>
                </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $diff = ($now->diffInSeconds($item->created_at));
                $daily = $item->speed*$gnl->daily;
                $perSec = $daily/86400;
                $total = $diff*$perSec;
                $balance = $total - $item->withdraw;    
                ?>
                <tr>
                    <td><?php echo e($item->speed); ?> DH/S</td>
                    <td><?php echo e(round($balance,8)); ?> <?php echo e($gnl->cur); ?></td>
                    <td><?php echo e(round($item->withdraw,8)); ?> <?php echo e($gnl->cur); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                    <td><?php echo e($item->status==1?'Active':'Expired'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
    </div>
</div>
<hr>
<div class="card">
    <div class="card-header">
        DEPOSIT of <strong><?php echo e($account->uqid); ?></strong>
    </div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>AMOUNT</th>
                    <th>WALLET</th>
                    <th>TRX ID</th>
                    <th>TRX TIME</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($deposit)==0): ?>
                <tr>
                    <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->amount); ?> <?php echo e($gnl->cur); ?></td>
                    <td><?php echo e($item->wallet); ?></td>
                    <td><?php echo e($item->trx); ?></td>
                    <td><?php echo e($item->updated_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
    </div>
</div>
<hr>
<div class="card">
    <div class="card-header">
        PAYOUTS of <strong><?php echo e($account->uqid); ?></strong>
    </div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>AMOUNT</th>
                    <th>WALLET</th>
                    <th>TRX ID</th>
                    <th>TRX TIME</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($withdraw)==0): ?>
                <tr>
                    <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->amount); ?> <?php echo e($gnl->cur); ?></td>
                    <td><?php echo e($item->account->wallet); ?></td>
                    <td><?php echo e($item->trx); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>