<?php $__env->startSection('content'); ?>
    <section id="transaction">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading-title2">
                        <p>
                            <?php echo e($gnl->title); ?>

                        </p>
                        <h2>
                            WITHDRAW
                        </h2>
                    </div>
                </div>
                <div class="col-12 text-center">

                    <div class="card rich" style=" background-color: transparent; color:white; border:1px solid #dee2e6" id="depositCard" style="display:none;">

                        <div class="card-body">
                            <form id="withdrawForm">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group" >
                                            <select name="track" id="trackId" style=" background-color: transparent; color:white; border:1px solid #dee2e6" id="depositCard" style="display:none;" class="form-control wallet-input">
                                                <option>Select A MINER</option>
                                                <?php $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option style="background: black;" value="<?php echo e($item->id); ?>"><?php echo e(round($item->balance,8)); ?> <?php echo e($gnl->cur); ?> | <?php echo e($item->speed); ?> DH/S</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <div class="input-group-append">
                                                <input type="number" style=" background-color: transparent; color:white; border:1px solid #dee2e6; " id="depositCard"  class="form-control input-lg wallet-input" name="amount" placeholder="Withdraw Amount">
                                                <span class="input-group-text wallet-input"><?php echo e($gnl->cur); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary btn-block btn-submit">Enter</button>
                                    </div>
                                </div>
                            </form>

                            <hr>
                            <ul class="list-inline">
                                <li class="list-inline-item">Minimum Withdraw: <strong><?php echo e($gateway->minimum); ?></strong> <?php echo e($gnl->cur); ?> |</li>
                                <li class="list-inline-item">Your Balance <strong><?php echo e(isset($balance) ? round($balance, $gnl->decimal) : 0); ?></strong> <?php echo e($gnl->cur); ?></li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <br>
            <hr>
            <div class="row justify-content-center">
                <h3 style="color: white"> YOUR PAYOUTS</h3>
                <div class="col-md-12">
                    <br>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>AMOUNT</th>
                                <th>TRX ID</th>
                                <th>TRX TIME</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($withdraw)==0): ?>
                                <tr>
                                    <td class="text-center" colspan="3">NO DATA AVAILABLE</td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->amount); ?> <?php echo e($gnl->cur); ?></td>
                                    <td><?php echo e($item->trx); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php echo e($withdraw->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function(){  
    $(document).on('submit','#withdrawForm',function(event)
    {
      event.preventDefault();
      $.ajax({
        type:"POST",
        url:"<?php echo e(route('account.withdraw-post')); ?>",       
        data: new FormData(document.getElementById('withdrawForm')),
        contentType: false,
        processData: false,
        success:function(data)
        {
          console.log(data)
          if(data==99)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Invalid Amount" }, { type: 'danger' });
          }
          if(data==33)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Select A Track" }, { type: 'danger' });
          }
          else if(data == 11)
          {
            $.notify({ allow_dismiss: true,title: "Success!",message: "Withdraw Complete" }, { type: 'success' });
          }
          else
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Error Occured" }, { type: 'danger' });
          }
        }
      });
    });
  });
</script>     

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>