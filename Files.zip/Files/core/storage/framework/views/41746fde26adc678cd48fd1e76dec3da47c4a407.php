<!DOCTYPE html>
<html lang="en">

<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?php echo e($gnl->title); ?>, <?php echo e($gnl->subtitle); ?>">
    <meta name="author" content="<?php echo e($gnl->title); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/icon.png')); ?>" type="image/x-icon">
    <title><?php echo e($gnl->title); ?> - ADMIN</title>
    
    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(asset('assets/admin/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    
    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('assets/admin/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    
    <!-- Page level plugin CSS-->
    <link href="<?php echo e(asset('assets/admin/vendor/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
    
    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('assets/admin/css/sb-admin.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/admin/css/custom.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body id="page-top">
    
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
        
        <a class="navbar-brand mr-1" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" style="max-width:160px;">
        </a>
        
        <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
            <i class="fas fa-bars"></i>
        </button>
        
        <!-- Navbar Search -->
        <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">

        </form>
        
        <!-- Navbar -->
        <ul class="navbar-nav ml-auto ml-md-0">
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-user-circle fa-fw"></i>   <?php echo e(Auth::user()->name); ?>

                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?php echo e(route('admin.profile')); ?>">Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        </ul>
        
    </nav>
    
    <div id="wrapper">
        
        <!-- Sidebar -->
        <ul class="sidebar navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-fw fa-cogs"></i>
                    <span>General Settings</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                    <h6 class="dropdown-header">General Settings:</h6>
                    <a class="dropdown-item" href="<?php echo e(route('admin.general')); ?>">Website Info</a>
                    <a class="dropdown-item" href="<?php echo e(route('admin.logo')); ?>">Logo Icon</a>
                </div>
            </li>
            <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.accounts')); ?>">
                        <i class="fas fa-fw fa-users"></i>
                        <span>USER ACCOUNTS</span>
                    </a>
                </li>
            <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.gateway')); ?>">
                        <i class="fas fa-fw fa-university"></i>
                        <span>Payment Gateway</span>
                    </a>
                </li>
            <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.deposits')); ?>">
                        <i class="fas fa-fw fa-wallet"></i>
                        <span>DEPOSITS</span>
                    </a>
                </li>
            <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.withdraws')); ?>">
                        <i class="fas fa-fw fa-credit-card"></i>
                        <span>PAYOUTS</span>
                    </a>
                </li>

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-fw fa-globe"></i>
                    <span>Web Settings</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('howits.index')); ?>">How It's Work</a>
                    <a class="dropdown-item" href="<?php echo e(route('about-u.index')); ?>">About Us</a>
                    <a class="dropdown-item" href="<?php echo e(route('counter.index')); ?>">Statistic Counter</a>
                    <a class="dropdown-item" href="<?php echo e(route('service.index')); ?>">Services</a>
                    <a class="dropdown-item" href="<?php echo e(route('testimonial.index')); ?>">Testimonial</a>
                    <a class="dropdown-item" href="<?php echo e(route('admin.faq')); ?>">Faq</a>
                </div>
            </li>

          
        </ul> 
        
        <div id="content-wrapper">
            
            <div class="container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- /.container-fluid -->
            
            <!-- Sticky Footer -->
            <footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright © <?php echo e($gnl->title); ?> <?php echo e(date('Y')); ?></span>
                    </div>
                </div>
            </footer>
            
        </div>
        <!-- /.content-wrapper -->
        
    </div>
    <!-- /#wrapper -->
    
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    
    
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('assets/admin/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('assets/admin/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    
    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('assets/admin/js/sb-admin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/notify.min.js')); ?>"></script>
    <?php echo $__env->make('layouts.notify', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
