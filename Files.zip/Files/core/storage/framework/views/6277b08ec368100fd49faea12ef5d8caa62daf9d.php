

<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">PAYOUTS</li>
</ol>
<div class="card">
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>ACCOUNT</th>
                    <th>AMOUNT</th>
                    <th>TRX ID</th>
                    <th>TRX TIME</th>
                </tr>
            </thead>
            <tbody>
                    <?php if(count($withdraws)==0): ?>
                    <tr>
                        <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                    </tr>
                    <?php endif; ?>
                <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('admin.single', $item->account_id)); ?>"><?php echo e($item->account->wallet); ?></a></td>
                    <td><?php echo e($item->amount); ?> <?php echo e($gnl->cur); ?></td>
                    <td><?php echo e($item->trx); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($withdraws->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>