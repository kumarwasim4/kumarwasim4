<!DOCTYPE html>

<html lang="zxx">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
    <meta name="keywords" content="<?php echo e($gnl->title); ?>">
    <meta name="description" content="<?php echo e($gnl->title); ?> - <?php echo e($gnl->subtitle); ?>">
    <title><?php echo e($gnl->title); ?> - <?php echo e($gnl->subtitle); ?></title>
    <!--Favicon-->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/icon.png')); ?>" />
    <!--Bootstrap Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/assets/front/css/bootstrap.css">
    <!--Slick Slider-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/assets/front/css/slick.css">
    <!--Font Awesome Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/assets/front/css/all.min.css">
    <!--Animate Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/assets/front/css/animate.css">
    <!--Venobox Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/assets/front/css/venobox.css">
    <!--Main Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/assets/front/css/style.css">
    <!--Responsive Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/assets/front/css/responsive.css">

    <?php echo $__env->yieldContent('styles'); ?>
    <link href="<?php echo e(asset('assets/user/color.php?color=')); ?><?php echo e($gnl->color); ?>&color2=<?php echo e($gnl->color_two); ?>" rel="stylesheet">
</head>

<body class="body-class index_1 home1">
<!--Start Preloader-->
<div class="site-preloader">
    <div class="spinner">
        <div class="double-bounce1"></div>
        <div class="double-bounce2"></div>
    </div>
</div>
<!--End Preloader-->
<!-- Main Menu Area Start -->
<header id="mainHeader" class="header">
    <!-- Start Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light p-0">
        <div class="container">
            <a class="navbar-brand" <?php if(request()->path() == '/'): ?> href="#welcomeArea"  <?php else: ?> href="<?php echo e(url('/')); ?>" <?php endif; ?>>
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" style="max-width:210px;">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <?php if(session('CurrentAccount')==''): ?>
                        <li class="nav-item">
                            <a class="nav-link" <?php if(request()->path() == '/'): ?> href="#hiw"  <?php else: ?> href="<?php echo e(url('/')); ?>#hiw" <?php endif; ?> >How it work</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" <?php if(request()->path() == '/'): ?> href="#feature"  <?php else: ?> href="<?php echo e(url('/')); ?>#feature" <?php endif; ?>  >Our Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" <?php if(request()->path() == '/'): ?>  href="#video" <?php else: ?> href="<?php echo e(url('/')); ?>#video" <?php endif; ?> >About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" <?php if(request()->path() == '/'): ?>  href="#transaction" <?php else: ?> href="<?php echo e(url('/')); ?>#transaction" <?php endif; ?> >Transaction</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" <?php if(request()->path() == '/'): ?>href="#faq"  <?php else: ?> href="<?php echo e(url('/')); ?>#faq" <?php endif; ?>  >FAQ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" <?php if(request()->path() == '/'): ?> href="#testimonial" <?php else: ?> href="<?php echo e(url('/')); ?>#testimonial" <?php endif; ?>  >Testimonial</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" <?php if(request()->path() == '/'): ?> href="<?php echo e(route('contact')); ?>" <?php else: ?> <?php endif; ?>  >Contact</a>
                        </li>
                        <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('account.dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('account.deposit')); ?>">Deposit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('account.withdraw')); ?>">Withdraw</a>
                        </li>
                    <?php endif; ?>

                    <?php if(session('CurrentAccount')!=''): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('account.exit')); ?>" onclick="event.preventDefault(); document.getElementById('exit-form').submit();">Exit</a>
                        <form id="exit-form" action="<?php echo e(route('account.exit')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <!-- End Navigation -->
    <div class="clearfix"></div>
</header>
<!-- Main Menu Area End -->
<?php echo $__env->yieldContent('content'); ?>

<!-- Footer Area Start -->
<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="logo text-center">
                        <a href="<?php echo e(url('/')); ?>">
                            <img class="mx-auto d-block" src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" style="max-width:210px;">
                        </a>
                        <div class="content">
                            <p class="fp">
                               <?php echo e($gnl->footer_text); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="container-fluid">
        <div class="row copyrightArea">
            <div class="col-12 text-center">
                <p>
                    Copyright &copy; <?php echo e($gnl->title); ?> <?php echo e(date('Y')); ?>

                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->

<!--Start ClickToTop-->
<div class="totop">
    <a href="#top"><i class="fa fa-arrow-up"></i></a>
</div>
<!--End ClickToTop-->


<!--jQuery JS-->
<script src="<?php echo e(url('/')); ?>/assets/front/js/jquery.min.js"></script>
<!--Bootstrap JS-->
<script src="<?php echo e(url('/')); ?>/assets/front/js/bootstrap.min.js"></script>

<script src="<?php echo e(url('/')); ?>/assets/front/js/popper.js"></script>
<!-- Slick Slider -->
<script src="<?php echo e(url('/')); ?>/assets/front/js/slick.min.js"></script>
<!-- counter -->
<script src="<?php echo e(url('/')); ?>/assets/front/js/waypoints.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/front/js/jquery.counterup.min.js"></script>
<!-- MpusemoverParallax JS-->
<script src="<?php echo e(url('/')); ?>/assets/front/js/TweenMax.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/front/js/mousemoveparallax.js"></script>
<!-- Venobox JS-->
<script src="<?php echo e(url('/')); ?>/assets/front/js/venobox.min.js"></script>

<script src="<?php echo e(asset('assets/user/js/notify.min.js')); ?>"></script>
<!--Main-->
<script src="<?php echo e(url('/')); ?>/assets/front/js/main.js"></script>

<?php echo $__env->make('layouts.notify', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?>
<script>
    $(document).ready(function(){
        var winheight = $(window).height() - 150;
        $('#justify-height').css('min-height',winheight+'px');
    });
</script>
<script>
    $(document).ready(function(){
        $(document).on('submit','#contactForm',function(event)
        {
            event.preventDefault();
            $.ajax({
                type:"POST",
                url:"<?php echo e(route('contact-message')); ?>",
                data: new FormData(document.getElementById('contactForm')),
                contentType: false,
                processData: false,
                success:function(data)
                {

                    if(data==200)
                    {
                        $.notify({ allow_dismiss: true,title: "Success!",message: "Message Sent Successfully" }, { type: 'success' });
                    }
                    else if(data==11)
                    {
                        $.notify({ allow_dismiss: true,title: "Sorry!",message: "Email Field is Required" }, { type: 'danger' });
                    }
                    else if(data==22)
                    {
                        $.notify({ allow_dismiss: true,title: "Sorry!",message: "Name Field is Required" }, { type: 'danger' });
                    }
                    else if(data==33)
                    {
                        $.notify({ allow_dismiss: true,title: "Sorry!",message: "Subject Field is Required" }, { type: 'danger' });
                    }
                    else if(data==44)
                    {
                        $.notify({ allow_dismiss: true,title: "Sorry!",message: "Message Field is Required" }, { type: 'danger' });
                    }
                    else
                    {
                        $.notify({ allow_dismiss: true,title: "Sorry!",message: "An Error Occured" }, { type: 'danger' });
                    }
                }
            });
        });
    });
</script>

</body>
