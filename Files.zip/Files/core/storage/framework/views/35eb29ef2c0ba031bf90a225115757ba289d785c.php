<?php $__env->startSection('content'); ?>
    <section id="transaction">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading-title2">
                        <p>
                            <?php echo e($gnl->title); ?>

                        </p>
                        <h2>
                            DEPOSIT
                        </h2>
                    </div>
                </div>
                <div class="col-12 text-center">

                    <div class="card rich" style=" background-color: transparent; color:white; border:1px solid #dee2e6">
                        <div class="card-header">
                            <h2>YOUR DEPOSIT ADDRESS</h2>
                        </div>
                        <div class="card-body">
                            <div class="card rich" style=" background-color: transparent; color:white; border:1px solid #dee2e6" id="depositCard" style="display:none;">
                                <div class="card-header">
                                    <h3 id="depositAddress"></h3>
                                </div>
                                <div class="card-body">
                                    <img id="depositQRCode" style='width:300px;' />
                                </div>
                            </div>
                            <hr>
                            <h1><i class="fas fa-spinner" id="delaySpiner" style="display:none;"></i></h1>
                            <form id="depositForm">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary btn-submit">GENERATE DEPOSIT ADDRESS</button>
                            </form>
                            <hr>
                            <ul class="list-inline">
                                <li class="list-inline-item">Minimum Deposit: <strong><?php echo e($gateway->minimum); ?></strong> <?php echo e($gnl->cur); ?> |</li>
                                <li class="list-inline-item">1 DH/S = <strong><?php echo e($gnl->dhs_price); ?></strong> <?php echo e($gnl->cur); ?> |</li>
                                <li class="list-inline-item">Daily <strong><?php echo e($gnl->daily); ?></strong> <?php echo e($gnl->cur); ?> Per DH/S</li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <br>
            <hr>
            <div class="row justify-content-center">
                <h3 style="color: white">   Your Deposits</h3>
                <div class="col-md-12">
                    <br>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>AMOUNT</th>
                                <th>WALLET</th>
                                <th>TRX ID</th>
                                <th>TRX TIME</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($deposits)==0): ?>
                                <tr>
                                    <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->amount); ?> <?php echo e($gnl->cur); ?></td>
                                    <td><?php echo e($item->wallet); ?></td>
                                    <td><?php echo e($item->trx); ?></td>
                                    <td><?php echo e($item->updated_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php echo e($deposits->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function(){  
    $(document).on('submit','#depositForm',function(event)
    {
      event.preventDefault();
      $('#delaySpiner').show();
      $.ajax({
        type:"POST",
        url:"<?php echo e(route('account.deposit-wallet')); ?>",       
        data: new FormData(document.getElementById('depositForm')),
        contentType: false,
        processData: false,
        success:function(data)
        {
          if(data==99)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Error Occurd" }, { type: 'danger' });
          }
          else
          {
            $('#delaySpiner').hide();            
            $('#depositCard').show();
            $('#depositForm').hide();
            $('#depositAddress').text(data);
            let qrcode = 'https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl='+data+'&choe=UTF-8';
            $('#depositQRCode').attr('src', qrcode);          
          }
        }
      });
    });
  });
</script>     
  
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>