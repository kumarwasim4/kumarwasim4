<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">General Settings</li>
</ol>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <form role="form" method="POST" action="<?php echo e(route('admin.gnlupdate')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-4">
                            <label>Website Title</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($general->title); ?>" name="title" required>
                        </div>
                        <div class="col-md-4">
                            <label>Website Sub-Title</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($general->subtitle); ?>" name="subtitle" required>
                        </div>
                        <div class="col-md-4">
                            <label>Contact Email</label>
                            <input type="email" class="form-control input-lg" value="<?php echo e($general->email); ?>" name="email" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <hr/>
                        </div>
                    </div>
                     <div class="row">
                        <div class="col-md-6">
                            <label>Address</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($general->address); ?>" name="address" required>
                        </div>
                        <div class="col-md-6">
                            <label>Phone</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($general->phone); ?>" name="phone" required>
                        </div>
                      
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <hr/>
                        </div>
                    </div>
                    <div class="row">
                        
                        
                        <div class="col-md-4">
                            <label>BASE CURRENCY CODE</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($general->cur); ?>" name="cur" >
                        </div>
                        <div class="col-md-4">
                            <label>BASE CURRENCY SYMBOL</label>
                            <input type="text" class="form-control input-lg" value="<?php echo e($general->cursym); ?>" name="cursym" >
                        </div>
                        <div class="col-md-4">
                            <label>DECIMAL AFTER POINT</label>
                            <input type="number" value="<?php echo e($general->decimal); ?>" name="decimal" class="form-control input-lg" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <hr/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label>DH/S Price</label>
                            <div class="input-group-append">
                                <span class="input-group-text">1 DH/S =</span>
                                <input type="text" class="form-control input-lg"  value="<?php echo e($general->dhs_price); ?>" name="dhs_price" required />
                                <span class="input-group-text"><?php echo e($gnl->cur); ?></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label>Free DH/S</label>
                            <div class="input-group-append">
                                <input type="number" class="form-control input-lg"  value="<?php echo e($general->free_dhs); ?>" name="free_dhs" required />
                                <span class="input-group-text">DH/S</span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label>Daily Earning Per DH/S</label>
                            <div class="input-group-append">
                                <input type="text" class="form-control input-lg"  value="<?php echo e($general->daily); ?>" name="daily" required />
                                <span class="input-group-text"><?php echo e($gnl->cur); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <hr/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <label>Footer Text</label>
                            <textarea class="form-control" rows="5" name="footer_text"><?php echo e($general->footer_text); ?></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <hr/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card bg-dark text-white">
                                <div class="card-header">LOGO</div>
                                <div class="card-body">
                                    <div class="form-group text-center">
                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail">
                                                <img src="<?php echo e(asset('assets/images/banner_image.png')); ?>" alt="" style="width:100%" />
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail"> </div>
                                            <hr>
                                            <div>
                                            <span class="btn btn-success btn-file">
                                                <span class="fileinput-new"> Change Banner Image </span>
                                                <span class="fileinput-exists"> Change </span>
                                                <input type="file" name="banner_image"> </span>
                                                <a href="javascript:;" class="btn btn-danger fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <hr/>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 ml-auto mr-auto">
                            <button class="btn btn-success btn-block btn-lg">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
	
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>