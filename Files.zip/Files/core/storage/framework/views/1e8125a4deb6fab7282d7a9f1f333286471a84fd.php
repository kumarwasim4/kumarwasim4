<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
  </li>
  <li class="breadcrumb-item active">Statistics</li>
</ol>

<!-- Page Content -->
<div class="card">
    <div class="card-header">MINING TRACKS
    </div>
    <div class="card-body">
        <table class="table table-responsive-lg table-striped">
            <thead>
                <tr>
                    <th>ACCOUNT</th>
                    <th>SPEED</th>
                    <th>BALANCE</th>
                    <th>WITHDRAW</th>
                    <th>START AT</th>
                    <th>STATUS</th>
                </tr>
            </thead>
            <tbody>
                    <?php if(count($tracks)==0): ?>
                    <tr>
                        <td class="text-center" colspan="6">NO DATA AVAILABLE</td>
                    </tr>
                    <?php endif; ?>
                <?php $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                 $diff = ($now->diffInSeconds($item->created_at));
                 $daily = $item->speed*$gnl->daily;
                 $perSec = $daily/86400;
                 $total = $diff*$perSec;
                 $balance = $total - $item->withdraw;    
                ?>
                <tr>
                    <td><a href="<?php echo e(route('admin.single', $item->account_id)); ?>"><?php echo e($item->account->wallet); ?></a></td>
                    <td><?php echo e($item->speed); ?> DH/S</td>
                    <td><?php echo e(round($balance,8)); ?> <?php echo e($gnl->cur); ?></td>
                    <td><?php echo e(round($item->withdraw,8)); ?> <?php echo e($gnl->cur); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                    <td><?php echo e($item->status==1?'Active':'Expired'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($tracks->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>