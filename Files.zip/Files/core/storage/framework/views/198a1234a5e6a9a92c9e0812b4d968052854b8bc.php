<?php $__env->startSection('content'); ?>
    <!-- Feature Area Start -->
    <section id="feature">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading-title2">
                        <p>
                            &nbsp;
                        </p>
                        <h2>
                            Contact Us
                        </h2>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <footer id="footer">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <div class="title">

                        <form id="contactForm" >
                            <?php echo csrf_field(); ?>
                            <input type="text" name="name" placeholder="Your name here*" required>
                            <input type="email" name="email" placeholder="Your email here*" required>
                            <input type="text" name="subject" placeholder="Your email here*" required>
                            <textarea name="message" id="message" placeholder="Massege*"></textarea>
                            <button type="submit" class="offset-md-5">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- Feature Area End -->
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function(){  
    $(document).on('submit','#contactForm',function(event)
    {
      event.preventDefault();
      $.ajax({
        type:"POST",
        url:"<?php echo e(route('contact-message')); ?>",       
        data: new FormData(document.getElementById('contactForm')),
        contentType: false,
        processData: false,
        success:function(data)
        {
            if(data==200)
          {
            $.notify({ allow_dismiss: true,title: "Success!",message: "Message Sent Successfully" }, { type: 'success' });
          }
          else if(data==11)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Email Field is Required" }, { type: 'danger' });
          }
          else if(data==22)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Name Field is Required" }, { type: 'danger' });
          }
          else if(data==33)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Subject Field is Required" }, { type: 'danger' });
          }
          else if(data==44)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Message Field is Required" }, { type: 'danger' });
          }
          else
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "An Error Occured" }, { type: 'danger' });
          }
        }
      });
    });
  });
</script>     
  
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>