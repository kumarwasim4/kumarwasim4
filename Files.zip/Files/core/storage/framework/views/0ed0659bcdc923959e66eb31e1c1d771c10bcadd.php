<?php $__env->startSection('content'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">General Settings</li>
    <li class="breadcrumb-item active">
        <a href="https://fontawesome.com/v4.7.0/icons/" target="_blank" class="btn btn-primary">Font Awesome Icons</a>
    </li>
</ol>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <form role="form" method="POST" action="<?php echo e(route('admin.gnlupdate')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>How It's Work 1</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Icon <i class="fa fa-<?php echo e($general->how_icon_1); ?>"></i></label>
                                        <input type="text" class="form-control input-lg" value="<?php echo e($general->how_icon_1); ?>" name="how_icon_1" required>
                                    </div>
                                     <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control input-lg" value="<?php echo e($general->how_text_1); ?>" name="how_text_1" required>
                                    </div>

                                </div>
                            </div>

                        </div>


                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>How It's Work 2</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Icon <i class="fa fa-<?php echo e($general->how_icon_2); ?>"></i></label>
                                        <input type="text" class="form-control input-lg" value="<?php echo e($general->how_icon_2); ?>" name="how_icon_2" required>
                                    </div>
                                     <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control input-lg" value="<?php echo e($general->how_text_2); ?>" name="how_text_2" required>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>How It's Work 3</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Icon <i class="fa fa-<?php echo e($general->how_icon_3); ?>"></i></label>
                                        <input type="text" class="form-control input-lg" value="<?php echo e($general->how_icon_3); ?>" name="how_icon_3" required>
                                    </div>
                                     <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control input-lg" value="<?php echo e($general->how_text_3); ?>" name="how_text_3" required>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>How It's Work 4</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Icon <i class="fa fa-<?php echo e($general->how_icon_4); ?>"></i></label>
                                        <input type="text" class="form-control input-lg" value="<?php echo e($general->how_icon_4); ?>" name="how_icon_4" required>
                                    </div>
                                     <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control input-lg" value="<?php echo e($general->how_text_4); ?>" name="how_text_4" required>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                  <br>
                    
                    <div class="row">
                        <div class="col-md-6 ml-auto mr-auto">
                            <button class="btn btn-success btn-block btn-lg">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
	
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>