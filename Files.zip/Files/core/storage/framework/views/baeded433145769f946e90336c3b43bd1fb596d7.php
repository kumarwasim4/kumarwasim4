<?php $__env->startSection('content'); ?>

    <!-- Welcome Area Start -->
    <section id="welcomeArea">
        <div class="container">
            <div class="row welcomaareaRow">
                <div class="col-md-6 d-flex align-self-center">
                    <div class="left">
                        <h1><?php echo e($gnl->title); ?></h1>
                        <span><?php echo e($gnl->subtitle); ?></span>
                        <div class="searcAddress">
                            <?php if(session('CurrentAccount')==''): ?>
                            <form id="checkForm">
                                <?php echo csrf_field(); ?>
                                <input type="text" class="wallet-input" name="wallet" placeholder="Your Dogecoin Address...">
                                <button type="submit">Enter</button>
                            </form>
                            <?php endif; ?>
                        </div>
                        <div class="info">
                            <h3>
                                <strong id="minedAmount">0</strong> <?php echo e($gnl->cur); ?>

                            </h3>
                            <p>
                                MINER SPEED: <strong>5</strong> DH/S  | DAILY PROFIT <strong id="dailyAmount"><?php echo e(5*$gnl->daily); ?></strong> <?php echo e($gnl->cur); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 d-flex dSmNone align-self-center">
                    <div class="right">
                        <div class="background">
                            <img class="img-fluid" style="margin-left: 50px;" src="<?php echo e(url('/')); ?>/assets/images/banner_image.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Welcome Area End -->

    <!-- How it Works Area Start -->
    <section id="hiw">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading-title">
                        <p>
                            <?php echo e($gnl->title); ?> Cloud Mining
                        </p>
                        <h2>
                            How It Work?
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-3">
                    <div class="box box1">
                        <i class="fas fa-<?php echo e($gnl->how_icon_1); ?>"></i>
                        <p>
                            <?php echo e($gnl->how_text_1); ?>

                        </p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="box box2">
                        <i class="fas fa-<?php echo e($gnl->how_icon_2); ?>"></i>
                        <p>
                            <?php echo e($gnl->how_text_2); ?>

                        </p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="box box3">
                        <i class="fas fa-<?php echo e($gnl->how_icon_3); ?>"></i>
                        <p>
                            <?php echo e($gnl->how_text_3); ?>

                        </p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="box box4">
                        <i class="fas fa-<?php echo e($gnl->how_icon_4); ?>"></i>
                        <p>
                            <?php echo e($gnl->how_text_4); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- How it Works Area End -->
    <!-- Feature Area Start -->
    <section id="feature">
        <div class="container">
            <div class="row">
               <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="box d-flex">
                        <div class="left d-flex">
                            <p class="d-flex align-self-center">
                                <i class="fas fa-<?php echo e($data->icon); ?>"></i>
                            </p>
                        </div>
                        <div class="right">
                            <h4>
                                <?php echo e($data->title); ?>

                            </h4>
                            <p>
                               <?php echo e($data->detail); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Feature Area End -->
    <!-- video Area Start -->
    <section id="video">
        <div class="container">
            <div class="row">
                <div class="col-md-6 d-flex align-self-center">
                    <div class="left">
                        <div class="heading-title">
                            <p>
                                About <?php echo e($gnl->title); ?>

                            </p>
                        </div>
                        <div class="content">
                            <p>
                               <?php echo $gnl->about_text; ?>

                            </p>
                            <div class="videoBox">
                                <a class="venobox" data-vbtype="video" data-autoplay="true" href="<?php echo e($gnl->about_video); ?>">
                                    <i class="fas fa-play"></i>
                                </a>
                                <span>
									Watch  movie
								</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="right">
                        <div class="parallax1">
                            <img class="img-fluid" style="    margin-left: 70px;" src="<?php echo e(url('/')); ?>/assets/images/about_image.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- video Area End  -->

    <!-- Transaction Area Start -->
    <section id="transaction">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading-title2">
                        <p>
                            Transaction
                        </p>
                        <h2>
                            DogeMiner Transaction
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-8 ">
                    <div class="tab1">
                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home"
                                   aria-selected="true">
                                    <p>
                                        LAST 25 DEPOSITS
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile"
                                   aria-selected="false">
                                    <p>
                                        LAST 25 PAYOUTS
                                    </p>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>AMOUNT</th>
                                            <th>WALLET</th>
                                            <th>TRX ID</th>
                                            <th>TRX TIME</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($deposit)==0): ?>
                                            <tr>
                                                <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->amount); ?> <?php echo e($gnl->cur); ?></td>
                                                <td><?php echo e(substr_replace($item->account->wallet, 'XXX', -3)); ?></td>
                                                <td><?php echo e($item->trx); ?></td>
                                                <td><?php echo e($item->updated_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>AMOUNT</th>
                                            <th>WALLET</th>
                                            <th>TRX ID</th>
                                            <th>TRX TIME</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($withdraw)==0): ?>
                                            <tr>
                                                <td class="text-center" colspan="4">NO DATA AVAILABLE</td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->amount); ?> <?php echo e($gnl->cur); ?></td>
                                                <td><?php echo e(substr_replace($item->account->wallet, 'XXX', -3)); ?></td>
                                                <td><?php echo e($item->trx); ?></td>
                                                <td><?php echo e($item->created_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Transaction Area End -->
    <!-- Counter Area Start -->
    <section id="counter">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-3">
                    <div class="cWrapper">
                        <div class="box box1 d-flex">
                            <div class="left d-flex align-self-center">
                                <p>
                                    <i class="fas fa-<?php echo e($gnl->count_icon_1); ?>"></i>
                                </p>
                            </div>
                            <div class="right">
                                <div class="content">
                                    <span class="count"><?php echo e($gnl->count_number_1); ?></span>
                                    <p>
                                        <?php echo e($gnl->count_title_1); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="cWrapper">
                        <div class="box box2 d-flex">
                            <div class="left d-flex align-self-center">
                                <p>
                                    <i class="fas fa-<?php echo e($gnl->count_icon_2); ?>"></i>
                                </p>
                            </div>
                            <div class="right">
                                <span class="count"><?php echo e($gnl->count_number_2); ?></span>
                                <p>
                                    <?php echo e($gnl->count_title_1); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="cWrapper">
                        <div class="box box3 d-flex">
                            <div class="left d-flex align-self-center">
                                <p>
                                    <i class="fas fa-<?php echo e($gnl->count_icon_3); ?>"></i>
                                </p>
                            </div>
                            <div class="right">
                                <span class="count"><?php echo e($gnl->count_number_3); ?></span>
                                <p>
                                    <?php echo e($gnl->count_title_1); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="cWrapper">
                        <div class="box box4 d-flex">
                            <div class="left d-flex align-self-center">
                                <p>
                                    <i class="fas fa-<?php echo e($gnl->count_icon_4); ?>"></i>
                                </p>
                            </div>
                            <div class="right">
                                <span class="count"><?php echo e($gnl->count_number_4); ?></span>
                                <p>
                                    <?php echo e($gnl->count_title_1); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Counter Area End -->

    <!-- FAQ Area Start -->
    <section id="faq">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading-title2">
                        <p>
                            FAQ’s
                        </p>
                        <h2>
                            Frequently Asking Question’s
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="faq-accordian">
                        <div class="panel-group accordion" id="accordionId">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="panel panel-default">
                                        <div class="panel-heading" id="headingOne<?php echo e($item->id); ?>">
                                            <h4 class="panel-title">
                                                <a class="" data-toggle="collapse" data-target="#collapse1<?php echo e($item->id); ?>" aria-expanded="false" aria-controls="collapse1<?php echo e($item->id); ?>">
                                                    <?php echo e($item->title); ?></a>
                                            </h4>
                                        </div>
                                        <div id="collapse1<?php echo e($item->id); ?>" class="collapse" aria-labelledby="headingOne<?php echo e($item->id); ?>" data-parent="#accordionId">
                                            <div class="panel-body">
                                                <?php echo e($item->details); ?>

                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- FAQ Area End -->

    <!-- Testimonial Area Start -->
    <section id="testimonial">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-md-10 col-lg-9">
                    <div class="slider slider-for">

                        <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Client Feedback Text  -->
                        <div class="client-feedback-text text-center">
                            <div class="client-description text-center">
                                <p>
                                    “<?php echo e($data->comment); ?>”
                                </p>
                            </div>
                            <div class="client-name text-center">
                                <h5><?php echo e($data->name); ?> -</h5>
                                <p><?php echo e($data->company); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonial Area End -->
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function(){  
    let daily = $('#dailyAmount').text();
    let inMili = daily/864000;
    let incVal = 0;
    setInterval(function(){ 
      incVal = incVal+inMili;
      $('#minedAmount').text(incVal.toFixed(8)); 
    }, 100);
    
    
    $(document).on('submit','#checkForm',function(event)
    {
      event.preventDefault();
      $.ajax({
        type:"POST",
        url:"<?php echo e(route('account.check')); ?>",       
        data: new FormData(document.getElementById('checkForm')),
        contentType: false,
        processData: false,
        success:function(data)
        {
          console.log(data)
          if(data==99)
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Invalid DOGE Address" }, { type: 'danger' });
          }
          else if(data==11)
          {
            $.notify({ allow_dismiss: true,title: "Success!",message: "Account Found" }, { type: 'success' });
            window.location.href = "<?php echo e(route('account.dashboard')); ?>";
          }
          else if(data==12)
          {
            $.notify({ allow_dismiss: true,title: "Success!",message: "Account Created" }, { type: 'success' });
            window.location.href = "<?php echo e(route('account.dashboard')); ?>";
          }
          else
          {
            $.notify({ allow_dismiss: true,title: "Sorry!",message: "Error Occured" }, { type: 'danger' });
          }
        }
      });
    });
  });
</script>     

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>